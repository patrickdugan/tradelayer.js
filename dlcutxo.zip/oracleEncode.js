/**
 * Oracle Staking & Fraud Proof Encoders
 * Add these to your existing txEncoder.js
 * 
 * Uses ref:N pattern for addresses (like commit)
 * Uses base36 encoding consistent with existing TradeLayer
 * 
 * Type 104: TX_ORACLE_STAKE - Stake/unstake sBTC for DLC oracle operations
 * Type 105: TX_FRAUD_PROOF - Challenge oracle state attestation
 * Type 108: TX_REGISTER_DLC_ADDRESS - Register a fundable DLC address
 * 
 * Token Type 1 (issueToken) extended with dlcOracleId for rBTC-style tokens
 */

const BigNumber = require('bignumber.js');

// Oracle stake action types
const OracleStakeAction = {
    STAKE: 0,           // Initial stake or add to stake
    REQUEST_UNBOND: 1,  // Start unbonding period
    COMPLETE_UNBOND: 2, // Withdraw after unbonding period
    SLASH: 3            // System-initiated slash (internal)
};

// Fraud proof types
const FraudProofType = {
    BALANCE_MISMATCH: 0,    // rBTC balance doesn't match oracle attestation
    DOUBLE_SPEND: 1,        // Oracle attested to spent UTXO
    INVALID_SETTLEMENT: 2,  // DLC settlement outcome incorrect
    STATE_REPLAY_FAIL: 3    // Replay from checkpoint contradicts attestation
};

// DLC enum resolution types (for settlement granularity)
const DLCEnumType = {
    BINARY: 0,              // Simple win/lose (0% or 100%)
    INCREMENTAL_5: 1,       // 5% increments (0,5,10...100) = 21 outcomes
    INCREMENTAL_10: 2,      // 10% increments = 11 outcomes
    HALF_REMAINDER: 3       // <=50% with remainder roll
};

const marker = 'tl';

const OracleEncode = {

    /**
     * Type 104: TX_ORACLE_STAKE
     * Stake sBTC tokens for oracle operations with unbonding period
     * 
     * @param {Object} params
     * @param {number} params.action - OracleStakeAction enum
     * @param {number} params.oracleId - Oracle property ID being staked for
     * @param {string} params.amount - Amount in satoshis
     * @param {number} params.quorumId - Optional quorum to join (0 = solo)
     */
    encodeOracleStake: (params) => {
        const action = (params.action ?? 0).toString(36);
        const oracleId = (params.oracleId ?? 0).toString(36);
        const amount = new BigNumber(params.amount ?? 0).toString(36);
        const quorumId = (params.quorumId ?? 0).toString(36);
        
        const payload = [action, oracleId, amount, quorumId].join(',');
        const type = 104;
        const typeStr = type.toString(36);
        return marker + typeStr + payload;
    },

    /**
     * Type 105: TX_FRAUD_PROOF
     * Challenge an oracle's state attestation
     * 
     * Uses ref:N for challengeAddress (output vout reference)
     * 
     * @param {Object} params
     * @param {number} params.fraudType - FraudProofType enum
     * @param {number} params.oracleId - Oracle being challenged
     * @param {number} params.challengeBlock - Block containing the disputed attestation
     * @param {string} params.activationCodeHash - Code hash at last activation block (hex)
     * @param {string} params.checkpointHash - Consensus hash at persistence checkpoint (hex)
     * @param {number} params.ref - Reference output vout for challenge address
     * @param {string} params.claimedBalance - Oracle's claimed rBTC balance
     * @param {string} params.actualBalance - Challenger's computed rBTC balance
     */
    encodeFraudProof: (params) => {
        const fraudType = (params.fraudType ?? 0).toString(36);
        const oracleId = (params.oracleId ?? 0).toString(36);
        const challengeBlock = (params.challengeBlock ?? 0).toString(36);
        
        // Hashes stay as hex but truncate for OP_RETURN efficiency
        // First 16 bytes of each hash (32 hex chars)
        const activationCodeHash = (params.activationCodeHash ?? '').substring(0, 32);
        const checkpointHash = (params.checkpointHash ?? '').substring(0, 32);
        
        // Use ref:N pattern for challenge address
        const challengeRef = `ref:${params.ref ?? 0}`;
        
        const claimedBalance = new BigNumber(params.claimedBalance ?? 0).toString(36);
        const actualBalance = new BigNumber(params.actualBalance ?? 0).toString(36);
        
        const payload = [
            fraudType,
            oracleId,
            challengeBlock,
            activationCodeHash,
            checkpointHash,
            challengeRef,
            claimedBalance,
            actualBalance
        ].join(',');
        
        const type = 105;
        const typeStr = type.toString(36);
        return marker + typeStr + payload;
    },

    /**
     * Type 108: TX_REGISTER_DLC_ADDRESS
     * Register a fundable DLC address for a specific oracle
     * 
     * Uses ref:N for taproot address (output reference)
     * 
     * @param {Object} params
     * @param {number} params.dlcOracleId - DLC oracle property ID
     * @param {number} params.ref - Reference output vout containing the taproot address
     * @param {number} params.rollSlot - Which roll window slot (0-6 for weekly)
     * @param {number} params.enumBucket - Starting enum bucket (0, 5, 10... for 5% increments)
     * @param {boolean} params.autoRoll - Enable auto-roll on expiry if tokens remain
     * @param {number} params.cltvExpiry - Absolute block height for refund
     */
    encodeRegisterDLCAddress: (params) => {
        const dlcOracleId = (params.dlcOracleId ?? 0).toString(36);
        
        // Use ref:N pattern for taproot address
        const taprootRef = `ref:${params.ref ?? 0}`;
        
        const rollSlot = (params.rollSlot ?? 0).toString(36);
        const enumBucket = (params.enumBucket ?? 0).toString(36);
        const autoRoll = params.autoRoll ? '1' : '0';
        const cltvExpiry = (params.cltvExpiry ?? 0).toString(36);
        
        const payload = [
            dlcOracleId,
            taprootRef,
            rollSlot,
            enumBucket,
            autoRoll,
            cltvExpiry
        ].join(',');
        
        const type = 108;
        const typeStr = type.toString(36);
        return marker + typeStr + payload;
    },

    /**
     * Extended Token Issue for DLC-backed tokens (rBTC)
     * 
     * This extends the existing encodeTokenIssue with a dlcOracleId field
     * When dlcOracleId > 0, this creates a DLC-backed token type
     * 
     * @param {Object} params - Standard token issue params plus:
     * @param {number} params.dlcOracleId - Oracle ID for DLC-backed token (0 = normal token)
     */
    encodeTokenIssueWithDLC: (params) => {
        const initialAmount = (params.initialAmount ?? 0).toString(36);
        const ticker = params.ticker ?? '';
        const whitelists = params.whitelists 
            ? params.whitelists.map(w => w.toString(36)).join(';')
            : '';
        const managed = params.managed ? '1' : '0';
        const backupAddress = params.backupAddress ?? '';
        const nft = params.nft ? '1' : '0';
        const coloredCoinHybrid = params.coloredCoinHybrid ? '1' : '0';
        
        // NEW: DLC oracle ID - if > 0, this is a DLC-backed token (rBTC style)
        const dlcOracleId = (params.dlcOracleId ?? 0).toString(36);
        
        const payload = [
            initialAmount,
            ticker,
            whitelists,
            managed,
            backupAddress,
            nft,
            coloredCoinHybrid,
            dlcOracleId  // New field at end
        ].join(',');
        
        const type = 1;
        const typeStr = type.toString(36);
        return marker + typeStr + payload;
    }
};

module.exports = {
    OracleStakeAction,
    FraudProofType,
    DLCEnumType,
    OracleEncode,
    marker
};
