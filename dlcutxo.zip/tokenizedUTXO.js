/**
 * tokenizedUTXO.js - Fraud Proof State Replay for DLC-backed Tokens
 * 
 * Handles:
 * - State replay from persistence checkpoint to challenge block
 * - Merkle proof verification
 * - Code hash computation for activation blocks
 * - rBTC balance computation during replay
 * 
 * Works with:
 * - persistence.js for checkpoint loading
 * - main.js pattern for tx processing
 * - oracle.js extensions for attestation state
 * - tally.js for balance lookups
 */

const crypto = require('crypto');
const db = require('./db');
const BigNumber = require('bignumber.js');

// Would import these in actual integration:
// const TallyMap = require('./tally.js');
// const Persistence = require('./persistence.js');
// const Activation = require('./activation.js');
// const Consensus = require('./consensus.js');

const TokenizedUTXO = {

    // ============================================
    // CODE HASH COMPUTATION
    // ============================================

    /**
     * Compute the code hash at a specific activation block
     * This represents the consensus rules in effect
     * 
     * @param {Object} activation - Activation instance
     * @param {number} activationBlock - Block of last activation
     * @returns {string} - 32-byte hex hash (truncated to 16 bytes for efficiency)
     */
    computeCodeHash: async (activation, activationBlock) => {
        // Get all active transaction types at this block
        const activeTypes = [];
        for (let type = 0; type <= 110; type++) {
            const typeActivation = activation.getActivationBlock(type);
            if (typeActivation && typeActivation <= activationBlock) {
                activeTypes.push(type);
            }
        }
        
        // Build deterministic preimage
        const preimage = JSON.stringify({
            block: activationBlock,
            activeTypes: activeTypes.sort((a, b) => a - b)
        });
        
        const hash = crypto.createHash('sha256').update(preimage).digest('hex');
        // Return first 32 hex chars (16 bytes) for OP_RETURN efficiency
        return hash.substring(0, 32);
    },

    /**
     * Get last activation block before a given height
     */
    getLastActivationBefore: async (activation, targetBlock) => {
        // Find the highest activation block <= targetBlock
        let lastActivation = 0;
        for (let type = 0; type <= 110; type++) {
            const typeActivation = activation.getActivationBlock(type);
            if (typeActivation && typeActivation <= targetBlock && typeActivation > lastActivation) {
                lastActivation = typeActivation;
            }
        }
        return lastActivation || targetBlock;
    },

    // ============================================
    // CHECKPOINT VERIFICATION
    // ============================================

    /**
     * Get last persistence checkpoint before a block
     */
    getLastCheckpointBefore: async (persistence, targetBlock) => {
        // This would query the persistence checkpoint database
        const checkpointDB = await db.getDatabase('persistenceCheckpoints');
        
        const checkpoints = await checkpointDB.findAsync({
            block: { $lte: targetBlock }
        });
        
        if (checkpoints.length === 0) return null;
        
        // Find the latest checkpoint
        return checkpoints.reduce((latest, cp) => 
            cp.block > latest.block ? cp : latest
        );
    },

    /**
     * Compute consensus hash for a checkpoint
     * Matches the format stored by persistence.js
     */
    computeCheckpointHash: async (tallyMap, block) => {
        // Get all balances and hash them
        const allBalances = await tallyMap.getFullTallyMap();
        
        const preimage = JSON.stringify({
            block,
            balances: allBalances
        });
        
        const hash = crypto.createHash('sha256').update(preimage).digest('hex');
        return hash.substring(0, 32);
    },

    // ============================================
    // STATE REPLAY ENGINE
    // ============================================

    /**
     * Replay state from checkpoint to target block for a specific address
     * 
     * This mirrors main.js processTxSet but only tracks one address
     * 
     * @param {Object} config
     * @param {number} config.startBlock - Checkpoint block
     * @param {number} config.endBlock - Challenge block
     * @param {string} config.targetAddress - Address to compute state for
     * @param {string} config.codeHash - Expected code hash for validation
     * @param {Object} config.initialState - State at checkpoint for target address
     * @returns {Object} - { valid: boolean, error?: string, computedBalance: string }
     */
    replayState: async (config) => {
        const { startBlock, endBlock, targetAddress, codeHash, initialState } = config;

        try {
            // Initialize state from checkpoint
            let state = {
                rbtcBalance: initialState?.rbtcBalance || '0',
                balances: { ...(initialState?.balances || {}) }
            };

            // Get transactions between checkpoint and challenge block
            const txIndexDB = await db.getDatabase('txIndex');
            const allTxData = await txIndexDB.findAsync({});
            
            // Filter to transactions in our block range that involve the target address
            const relevantTxs = allTxData
                .filter(tx => tx._id.startsWith('tx-'))
                .filter(tx => {
                    const txBlock = parseInt(tx._id.split('-')[1]);
                    return txBlock > startBlock && txBlock <= endBlock;
                })
                .filter(tx => TokenizedUTXO.isRelevantTx(tx, targetAddress))
                .sort((a, b) => {
                    const blockA = parseInt(a._id.split('-')[1]);
                    const blockB = parseInt(b._id.split('-')[1]);
                    return blockA - blockB;
                });

            // Replay each transaction
            for (const txData of relevantTxs) {
                const result = TokenizedUTXO.applyTx(state, txData, targetAddress);
                if (!result.valid) {
                    return {
                        valid: false,
                        error: `Replay failed at ${txData._id}: ${result.error}`
                    };
                }
                state = result.newState;
            }

            return {
                valid: true,
                computedBalance: state.rbtcBalance,
                fullState: state
            };

        } catch (e) {
            return {
                valid: false,
                error: `Replay error: ${e.message}`
            };
        }
    },

    /**
     * Check if a transaction is relevant for the target address
     */
    isRelevantTx: (txData, targetAddress) => {
        const valueData = txData.value;
        if (!valueData) return false;
        
        const sender = valueData.sender?.senderAddress;
        const refs = valueData.reference;
        
        // Check sender
        if (sender === targetAddress) return true;
        
        // Check reference outputs
        if (Array.isArray(refs)) {
            for (const ref of refs) {
                if (ref.address === targetAddress) return true;
            }
        } else if (refs?.address === targetAddress) {
            return true;
        }
        
        return false;
    },

    /**
     * Apply a transaction to state
     * Only processes types that affect rBTC balances
     */
    applyTx: (state, txData, targetAddress) => {
        const newState = JSON.parse(JSON.stringify(state));
        const valueData = txData.value;
        
        if (!valueData || !valueData.payload) {
            return { valid: true, newState };
        }
        
        const payload = valueData.payload;
        const type = parseInt(payload.slice(0, 1).toString(36), 36);
        const sender = valueData.sender?.senderAddress;
        
        // Process types that can affect rBTC
        switch (type) {
            case 2: // Send
                // Would need to decode and check if it's rBTC property
                // For now, track general sends
                break;
                
            case 100: // TX_DLC_DEPOSIT_MINT (from DLC/NEAR work)
                // If recipient is target, add to rBTC balance
                // Would decode params.recipient and params.rbtcAmount
                break;
                
            case 101: // TX_REDEEM_BURN
                // If sender is target, subtract from rBTC balance
                break;
                
            case 106: // TX_PNL_SETTLEMENT
                // Handle DLC settlement P&L
                break;
                
            default:
                // Unknown or irrelevant type
                break;
        }
        
        return { valid: true, newState };
    },

    // ============================================
    // FRAUD PROOF VALIDATION
    // ============================================

    /**
     * Full fraud proof validation
     * Called from validity.js for TX 105
     * 
     * @param {Object} params - Decoded fraud proof params
     * @param {Object} oracles - Oracle instance
     * @param {Object} activation - Activation instance
     * @param {Object} persistence - Persistence instance
     * @returns {Object} - { valid: boolean, fraudConfirmed: boolean, ... }
     */
    validateFraudProof: async (params, oracles, activation, persistence) => {
        const {
            oracleId,
            challengeBlock,
            activationCodeHash,
            checkpointHash,
            challengeAddress,
            claimedBalance,
            actualBalance
        } = params;

        // 1. Verify oracle exists and is DLC type
        const oracle = await oracles.getOracleInfo(oracleId);
        if (!oracle || !oracle.isDLCOracle) {
            return { valid: false, error: 'Not a DLC oracle' };
        }

        // 2. Verify attestation exists
        const attestation = await oracles.getAttestation(oracleId, challengeBlock, challengeAddress);
        if (!attestation) {
            return { valid: false, error: 'No attestation found' };
        }

        // Verify claimed balance matches attestation
        if (attestation.rbtcBalance !== claimedBalance) {
            return { valid: false, error: 'Claimed balance does not match attestation' };
        }

        // 3. Verify activation code hash
        const lastActivation = await TokenizedUTXO.getLastActivationBefore(activation, challengeBlock);
        const computedCodeHash = await TokenizedUTXO.computeCodeHash(activation, lastActivation);
        
        if (computedCodeHash !== activationCodeHash) {
            return { valid: false, error: `Code hash mismatch: expected ${computedCodeHash}` };
        }

        // 4. Get checkpoint and verify hash
        const checkpoint = await TokenizedUTXO.getLastCheckpointBefore(persistence, challengeBlock);
        if (!checkpoint) {
            return { valid: false, error: 'No checkpoint found' };
        }
        
        if (checkpoint.consensusHash?.substring(0, 32) !== checkpointHash) {
            return { valid: false, error: 'Checkpoint hash mismatch' };
        }

        // 5. Get initial state for target address at checkpoint
        const checkpointState = checkpoint.addressStates?.[challengeAddress] || {
            rbtcBalance: '0',
            balances: {}
        };

        // 6. Replay state from checkpoint to challenge block
        const replayResult = await TokenizedUTXO.replayState({
            startBlock: checkpoint.block,
            endBlock: challengeBlock,
            targetAddress: challengeAddress,
            codeHash: activationCodeHash,
            initialState: checkpointState
        });

        if (!replayResult.valid) {
            return { valid: false, error: replayResult.error };
        }

        // 7. Compare replayed balance vs challenger's claim
        if (replayResult.computedBalance !== actualBalance) {
            return { 
                valid: false, 
                error: `Challenger claimed ${actualBalance} but replay computed ${replayResult.computedBalance}` 
            };
        }

        // 8. Determine if fraud occurred
        if (claimedBalance === actualBalance) {
            return {
                valid: true,
                fraudConfirmed: false,
                reason: 'No discrepancy - oracle attestation was correct'
            };
        }

        // Fraud confirmed!
        const slashAmount = await oracles.computeSlashAmount(
            oracleId,
            attestation.oracleAddress,
            claimedBalance,
            actualBalance
        );

        return {
            valid: true,
            fraudConfirmed: true,
            slashAmount,
            challengerReward: (BigInt(slashAmount) * 20n / 100n).toString(),
            discrepancy: (BigInt(actualBalance) - BigInt(claimedBalance)).toString()
        };
    },

    // ============================================
    // DLC ADDRESS FUNDING VALIDATION
    // ============================================

    /**
     * Validate a DLC address funding (for rBTC minting)
     * Checks the funding UTXO exists and matches the registered address
     */
    validateDLCFunding: async (oracles, fundingTxid, fundingVout, taprootAddress, amount) => {
        // Get DLC registration
        const registration = await oracles.getDLCAddressRegistration(taprootAddress);
        if (!registration) {
            return { valid: false, error: 'Address not registered' };
        }

        if (registration.status !== 'REGISTERED') {
            return { valid: false, error: `Invalid status: ${registration.status}` };
        }

        // Check roll slot capacity
        const capacity = await oracles.checkRollSlotCapacity(
            registration.dlcOracleId,
            registration.rollSlot,
            amount
        );

        if (!capacity.hasCapacity) {
            return { 
                valid: false, 
                error: `Roll slot at capacity. Available: ${capacity.available}` 
            };
        }

        // Would verify the actual UTXO exists on Bitcoin here
        // For now, mark as pending verification
        
        return {
            valid: true,
            registration,
            rollSlot: registration.rollSlot,
            enumBucket: registration.enumBucket
        };
    },

    // ============================================
    // AUTO-ROLL PROCESSING
    // ============================================

    /**
     * Process auto-roll for expired DLC addresses
     * Called at end of maturity window
     */
    processAutoRoll: async (oracles, tallyMap, oracleId, rollSlot, currentBlock) => {
        const dlcs = await oracles.getDLCsInRollSlot(oracleId, rollSlot);
        const rolledDLCs = [];

        for (const dlc of dlcs) {
            // Check if expired and has autoRoll
            if (dlc.cltvExpiry <= currentBlock && dlc.autoRoll && dlc.status === 'FUNDED') {
                // Check if address still has rBTC
                const oracle = await oracles.getOracleInfo(oracleId);
                const rbtcPropertyId = oracle.sbtcPropertyId; // or separate rbtcPropertyId
                
                const balance = await tallyMap.getBalance(dlc.taprootAddress, rbtcPropertyId);
                
                if (BigInt(balance || '0') > 0n) {
                    // Mark for roll
                    await oracles.updateDLCAddress(dlc.taprootAddress, {
                        status: 'ROLLED',
                        rolledBlock: currentBlock,
                        remainingBalance: balance
                    });

                    rolledDLCs.push({
                        original: dlc.taprootAddress,
                        remainingBalance: balance,
                        oracleId: dlc.dlcOracleId
                    });
                }
            }
        }

        return rolledDLCs;
    }
};

module.exports = TokenizedUTXO;
