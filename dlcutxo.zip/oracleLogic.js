/**
 * Oracle Staking & Fraud Proof Logic
 * Add these to your existing logic.js
 * 
 * Type 104: TX_ORACLE_STAKE
 * Type 105: TX_FRAUD_PROOF
 * Type 108: TX_REGISTER_DLC_ADDRESS
 */

const { OracleStakeAction, FraudProofType } = require('./oracleEncode.js');
const { UNBONDING_PERIOD_BLOCKS, SLASH_REWARD_PERCENT, FRAUD_PROOF_BOND } = require('./oracleExtensions.js');

const OracleLogic = {

    /**
     * Type 104: Execute Oracle Stake
     */
    executeOracleStake: async (params, tallyMap, oracles) => {
        const { action, oracleId, amount, quorumId, senderAddress, block, txid } = params;
        const amountBigInt = BigInt(amount);

        const oracle = await oracles.getOracleInfo(oracleId);
        const sbtcPropertyId = oracle.sbtcPropertyId;

        switch (action) {
            case OracleStakeAction.STAKE: {
                // Debit sBTC from sender
                await tallyMap.updateBalance(
                    senderAddress,
                    sbtcPropertyId,
                    -amountBigInt,
                    block,
                    txid,
                    'ORACLE_STAKE'
                );

                // Update stake record
                const existingStake = await oracles.getStake(oracleId, senderAddress);
                const newAmount = (BigInt(existingStake?.amount || '0') + amountBigInt).toString();

                await oracles.setStake(oracleId, senderAddress, {
                    amount: newAmount,
                    quorumId: quorumId || existingStake?.quorumId || 0,
                    stakedBlock: block,
                    unbondingBlock: 0,
                    unbondingAmount: '0',
                    active: true
                });

                // Update oracle total stake
                await oracles.updateTotalStake(oracleId, amountBigInt);

                console.log(`[OracleStake] ${senderAddress} staked ${amount} to oracle ${oracleId}`);
                break;
            }

            case OracleStakeAction.REQUEST_UNBOND: {
                const stake = await oracles.getStake(oracleId, senderAddress);
                
                await oracles.setStake(oracleId, senderAddress, {
                    ...stake,
                    unbondingBlock: block,
                    unbondingAmount: amount,
                    active: false
                });

                console.log(`[OracleUnbond] ${senderAddress} requested unbond of ${amount} from oracle ${oracleId}`);
                break;
            }

            case OracleStakeAction.COMPLETE_UNBOND: {
                const stake = await oracles.getStake(oracleId, senderAddress);
                const unbondAmount = BigInt(stake.unbondingAmount);

                // Credit sBTC back to sender
                await tallyMap.updateBalance(
                    senderAddress,
                    sbtcPropertyId,
                    unbondAmount,
                    block,
                    txid,
                    'ORACLE_UNBOND_COMPLETE'
                );

                // Update oracle total stake
                await oracles.updateTotalStake(oracleId, -unbondAmount);

                // Update or delete stake record
                const remaining = BigInt(stake.amount) - unbondAmount;
                if (remaining > 0n) {
                    await oracles.setStake(oracleId, senderAddress, {
                        ...stake,
                        amount: remaining.toString(),
                        unbondingBlock: 0,
                        unbondingAmount: '0',
                        active: true
                    });
                } else {
                    await oracles.deleteStake(oracleId, senderAddress);
                }

                console.log(`[OracleUnbondComplete] ${senderAddress} withdrew ${unbondAmount} from oracle ${oracleId}`);
                break;
            }
        }

        return { success: true };
    },

    /**
     * Type 105: Execute Fraud Proof
     */
    executeFraudProof: async (params, tallyMap, oracles) => {
        const {
            fraudType,
            oracleId,
            challengeBlock,
            challengeAddress,
            claimedBalance,
            actualBalance,
            senderAddress,
            block,
            txid,
            fraudConfirmed,
            slashAmount,
            challengerReward
        } = params;

        const oracle = await oracles.getOracleInfo(oracleId);
        const sbtcPropertyId = oracle.sbtcPropertyId;

        // Lock challenger's bond
        await tallyMap.updateBalance(
            senderAddress,
            sbtcPropertyId,
            -BigInt(FRAUD_PROOF_BOND),
            block,
            txid,
            'FRAUD_PROOF_BOND'
        );

        if (!fraudConfirmed) {
            // Fraud not confirmed - challenger loses bond to oracle pool
            await oracles.updateTotalStake(oracleId, BigInt(FRAUD_PROOF_BOND));
            
            // Resolve challenge as rejected
            await oracles.resolveChallenge(oracleId, txid, { confirmed: false });
            
            console.log(`[FraudProof] REJECTED - ${senderAddress} lost bond of ${FRAUD_PROOF_BOND}`);
            return { success: true, fraudConfirmed: false };
        }

        // Fraud confirmed - execute slashing

        // Get attestation to find oracle(s) to slash
        const attestation = await oracles.getAttestation(oracleId, challengeBlock, challengeAddress);
        const oracleAddresses = attestation.signers || [attestation.oracleAddress];

        // Slash each participating oracle
        for (const oracleAddr of oracleAddresses) {
            const stake = await oracles.getStake(oracleId, oracleAddr);
            if (!stake) continue;

            const oracleSlash = BigInt(slashAmount) / BigInt(oracleAddresses.length);
            const newStake = BigInt(stake.amount) - oracleSlash;

            if (newStake <= 0n) {
                await oracles.deleteStake(oracleId, oracleAddr);
            } else {
                await oracles.setStake(oracleId, oracleAddr, {
                    ...stake,
                    amount: newStake.toString(),
                    slashed: true,
                    slashedBlock: block,
                    slashedTxid: txid
                });
            }

            console.log(`[Slash] Oracle ${oracleAddr} slashed ${oracleSlash}`);
        }

        // Update oracle total stake
        await oracles.updateTotalStake(oracleId, -BigInt(slashAmount));

        // Reward challenger (bond return + reward)
        const totalReward = BigInt(challengerReward) + BigInt(FRAUD_PROOF_BOND);
        await tallyMap.updateBalance(
            senderAddress,
            sbtcPropertyId,
            totalReward,
            block,
            txid,
            'FRAUD_PROOF_REWARD'
        );

        // Invalidate attestation
        await oracles.invalidateAttestation(oracleId, challengeBlock, challengeAddress, {
            invalidatedBy: senderAddress,
            invalidatedBlock: block,
            invalidatedTxid: txid,
            actualBalance: actualBalance
        });

        // Resolve challenge as confirmed
        await oracles.resolveChallenge(oracleId, txid, { 
            confirmed: true,
            slashAmount,
            challengerReward: totalReward.toString()
        });

        console.log(`[FraudProof] CONFIRMED - ${senderAddress} received ${totalReward}`);
        console.log(`[FraudDetails] Oracle claimed ${claimedBalance}, actual was ${actualBalance}`);

        return { 
            success: true, 
            fraudConfirmed: true,
            slashedAmount: slashAmount,
            challengerReward: totalReward.toString()
        };
    },

    /**
     * Type 108: Execute Register DLC Address
     */
    executeRegisterDLCAddress: async (params, oracles) => {
        const {
            dlcOracleId,
            taprootAddress,
            rollSlot,
            enumBucket,
            autoRoll,
            cltvExpiry,
            senderAddress,
            block,
            txid
        } = params;

        await oracles.registerDLCAddress({
            dlcOracleId,
            taprootAddress,
            rollSlot,
            enumBucket,
            autoRoll,
            cltvExpiry,
            registeredBy: senderAddress,
            registeredBlock: block,
            registeredTxid: txid
        });

        console.log(`[RegisterDLCAddress] ${taprootAddress} for oracle ${dlcOracleId}`);
        console.log(`  Slot: ${rollSlot}, Bucket: ${enumBucket}%, AutoRoll: ${autoRoll}`);

        return { success: true };
    },

    /**
     * Create DLC-backed token (extends normal token issuance)
     * Called when dlcOracleId > 0 in token issuance
     */
    createDLCToken: async (params, propertyManager, oracles) => {
        const { dlcOracleId, ticker, senderAddress, block, txid } = params;

        // Create managed token with 0 initial supply
        const propertyId = await propertyManager.createProperty({
            issuer: senderAddress,
            name: ticker,
            type: 'managed',
            ecosystem: 1,
            divisibility: 8,
            block,
            txid,
            // DLC-specific metadata
            isDLCToken: true,
            dlcOracleId: dlcOracleId
        });

        // Link token to oracle
        const oracle = await oracles.getOracleInfo(dlcOracleId);
        if (oracle) {
            // Store the rBTC property ID on the oracle for reference
            await oracles.updateOracle(dlcOracleId, {
                rbtcPropertyId: propertyId
            });
        }

        console.log(`[CreateDLCToken] ${ticker} (ID: ${propertyId}) linked to oracle ${dlcOracleId}`);

        return { success: true, propertyId };
    }
};

module.exports = { OracleLogic };
