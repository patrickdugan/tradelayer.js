/**
 * Oracle Staking & Fraud Proof Validity
 * Add these to your existing validity.js
 * 
 * Type 104: TX_ORACLE_STAKE
 * Type 105: TX_FRAUD_PROOF  
 * Type 108: TX_REGISTER_DLC_ADDRESS
 * Type 1 extended: Token issuance with dlcOracleId
 */

const { OracleStakeAction, FraudProofType } = require('./oracleEncode.js');
const { OracleExtensions, UNBONDING_PERIOD_BLOCKS, MIN_STAKE_SATS, FRAUD_PROOF_BOND } = require('./oracleExtensions.js');
const TokenizedUTXO = require('./tokenizedUTXO.js');
const BigNumber = require('bignumber.js');

const OracleValidity = {

    /**
     * Type 104: Validate Oracle Stake
     */
    validateOracleStake: async (sender, params, txid, block, tallyMap, oracles, activation) => {
        params.reason = '';
        params.valid = true;

        // Activation check
        const isActivated = activation.getActivationBlock(104);
        if (!isActivated || block < isActivated) {
            params.valid = false;
            params.reason = 'Tx type 104 not yet activated';
            return params;
        }

        const { action, oracleId, amount, quorumId } = params;
        const amountBigInt = BigInt(amount);

        // Load oracle state
        const oracle = await oracles.getOracleInfo(oracleId);
        if (!oracle) {
            params.valid = false;
            params.reason = `Oracle ${oracleId} not found`;
            return params;
        }

        if (!oracle.isDLCOracle) {
            params.valid = false;
            params.reason = `Oracle ${oracleId} is not a DLC oracle`;
            return params;
        }

        const senderStake = await oracles.getStake(oracleId, sender);

        switch (action) {
            case OracleStakeAction.STAKE:
                // Check minimum stake
                if (amountBigInt < MIN_STAKE_SATS) {
                    params.valid = false;
                    params.reason = `Minimum stake is ${MIN_STAKE_SATS} satoshis`;
                    return params;
                }

                // Check sender has sBTC balance
                const senderBalance = await tallyMap.getBalance(sender, oracle.sbtcPropertyId);
                if (BigInt(senderBalance || '0') < amountBigInt) {
                    params.valid = false;
                    params.reason = `Insufficient sBTC balance. Have: ${senderBalance}, need: ${amount}`;
                    return params;
                }

                // Check no active fraud challenges
                const challenges = await oracles.getActiveChallenges(oracleId, sender);
                if (challenges && challenges.length > 0) {
                    params.valid = false;
                    params.reason = 'Cannot stake while fraud challenge is pending';
                    return params;
                }
                break;

            case OracleStakeAction.REQUEST_UNBOND:
                if (!senderStake || BigInt(senderStake.amount || '0') === 0n) {
                    params.valid = false;
                    params.reason = 'No stake to unbond';
                    return params;
                }

                if (amountBigInt > BigInt(senderStake.amount)) {
                    params.valid = false;
                    params.reason = `Cannot unbond ${amount}, only have ${senderStake.amount} staked`;
                    return params;
                }

                if (senderStake.unbondingBlock && senderStake.unbondingBlock > 0) {
                    params.valid = false;
                    params.reason = `Already unbonding since block ${senderStake.unbondingBlock}`;
                    return params;
                }

                // Check no active challenges
                const unbondChallenges = await oracles.getActiveChallenges(oracleId, sender);
                if (unbondChallenges && unbondChallenges.length > 0) {
                    params.valid = false;
                    params.reason = 'Cannot unbond while fraud challenge is pending';
                    return params;
                }
                break;

            case OracleStakeAction.COMPLETE_UNBOND:
                if (!senderStake || !senderStake.unbondingBlock || senderStake.unbondingBlock === 0) {
                    params.valid = false;
                    params.reason = 'No unbonding stake to complete';
                    return params;
                }

                const unlockBlock = senderStake.unbondingBlock + UNBONDING_PERIOD_BLOCKS;
                if (block < unlockBlock) {
                    params.valid = false;
                    params.reason = `Unbonding not complete. Current: ${block}, unlock: ${unlockBlock}`;
                    return params;
                }
                break;

            case OracleStakeAction.SLASH:
                params.valid = false;
                params.reason = 'SLASH action is system-initiated only';
                return params;

            default:
                params.valid = false;
                params.reason = `Unknown stake action: ${action}`;
                return params;
        }

        return params;
    },

    /**
     * Type 105: Validate Fraud Proof
     */
    validateFraudProof: async (sender, params, txid, block, tallyMap, oracles, activation, persistence) => {
        params.reason = '';
        params.valid = true;

        // Activation check
        const isActivated = activation.getActivationBlock(105);
        if (!isActivated || block < isActivated) {
            params.valid = false;
            params.reason = 'Tx type 105 not yet activated';
            return params;
        }

        const { oracleId } = params;

        // Load oracle
        const oracle = await oracles.getOracleInfo(oracleId);
        if (!oracle || !oracle.isDLCOracle) {
            params.valid = false;
            params.reason = `Oracle ${oracleId} is not a DLC oracle`;
            return params;
        }

        // Check challenger has fraud proof bond
        const senderBalance = await tallyMap.getBalance(sender, oracle.sbtcPropertyId);
        if (BigInt(senderBalance || '0') < FRAUD_PROOF_BOND) {
            params.valid = false;
            params.reason = `Insufficient fraud proof bond. Need: ${FRAUD_PROOF_BOND}`;
            return params;
        }

        // Delegate to TokenizedUTXO for full validation
        const fraudResult = await TokenizedUTXO.validateFraudProof(
            params, 
            oracles, 
            activation, 
            persistence
        );

        if (!fraudResult.valid) {
            params.valid = false;
            params.reason = fraudResult.error;
            return params;
        }

        // Copy results to params
        params.fraudConfirmed = fraudResult.fraudConfirmed;
        params.slashAmount = fraudResult.slashAmount;
        params.challengerReward = fraudResult.challengerReward;

        if (!fraudResult.fraudConfirmed) {
            params.reason = fraudResult.reason || 'No fraud detected';
        }

        return params;
    },

    /**
     * Type 108: Validate Register DLC Address
     */
    validateRegisterDLCAddress: async (sender, params, txid, block, oracles, activation) => {
        params.reason = '';
        params.valid = true;

        // Activation check
        const isActivated = activation.getActivationBlock(108);
        if (!isActivated || block < isActivated) {
            params.valid = false;
            params.reason = 'Tx type 108 not yet activated';
            return params;
        }

        const { dlcOracleId, taprootAddress, rollSlot, enumBucket, cltvExpiry } = params;

        // Load DLC oracle
        const oracle = await oracles.getOracleInfo(dlcOracleId);
        if (!oracle || !oracle.isDLCOracle) {
            params.valid = false;
            params.reason = `Oracle ${dlcOracleId} is not a DLC oracle`;
            return params;
        }

        // Verify sender is staked or admin
        const senderStake = await oracles.getStake(dlcOracleId, sender);
        const isAdmin = oracle.adminAddress === sender;
        
        if (!isAdmin && (!senderStake || BigInt(senderStake.amount || '0') < BigInt(oracle.minStake))) {
            params.valid = false;
            params.reason = 'Sender must be oracle admin or meet minimum stake';
            return params;
        }

        // Validate taproot address format
        if (!taprootAddress || !/^(bc1p|ltc1p|tb1p|tltc1p)[a-zA-HJ-NP-Z0-9]+$/.test(taprootAddress)) {
            params.valid = false;
            params.reason = 'Invalid Taproot address format';
            return params;
        }

        // Check address not already registered
        const existing = await oracles.getDLCAddressRegistration(taprootAddress);
        if (existing) {
            params.valid = false;
            params.reason = `Address ${taprootAddress} already registered`;
            return params;
        }

        // Validate roll slot
        const maxSlots = oracle.rollSlots?.length || 7;
        if (rollSlot < 0 || rollSlot >= maxSlots) {
            params.valid = false;
            params.reason = `Roll slot must be 0-${maxSlots - 1}`;
            return params;
        }

        // Validate enum bucket based on enum type
        const validBuckets = {
            0: [0, 100],
            1: [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100],
            2: [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100],
            3: [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50]
        };
        
        if (!validBuckets[oracle.enumType]?.includes(enumBucket)) {
            params.valid = false;
            params.reason = `Invalid enum bucket ${enumBucket} for enum type ${oracle.enumType}`;
            return params;
        }

        // Validate CLTV expiry
        const minExpiry = block + oracle.maturityWindow;
        if (cltvExpiry < minExpiry) {
            params.valid = false;
            params.reason = `CLTV expiry must be at least block ${minExpiry}`;
            return params;
        }

        return params;
    },

    /**
     * Extended Token Issue validation for DLC-backed tokens
     * 
     * When dlcOracleId > 0:
     * - Verifies the oracle exists and is DLC type
     * - Token becomes managed by the oracle for mint/burn
     */
    validateTokenIssueWithDLC: async (sender, params, txid, block, oracles) => {
        // If not a DLC token, use normal validation
        if (!params.dlcOracleId || params.dlcOracleId === 0) {
            return params; // Pass through to normal validation
        }

        // Verify DLC oracle exists
        const oracle = await oracles.getOracleInfo(params.dlcOracleId);
        if (!oracle) {
            params.valid = false;
            params.reason = `Oracle ${params.dlcOracleId} not found`;
            return params;
        }

        if (!oracle.isDLCOracle) {
            params.valid = false;
            params.reason = `Oracle ${params.dlcOracleId} is not a DLC oracle`;
            return params;
        }

        // Verify sender is oracle admin
        if (oracle.adminAddress !== sender) {
            params.valid = false;
            params.reason = `Only oracle admin can create DLC-backed tokens`;
            return params;
        }

        // DLC-backed tokens must be managed
        if (!params.managed) {
            params.valid = false;
            params.reason = 'DLC-backed tokens must be managed';
            return params;
        }

        // Initial amount should be 0 for DLC tokens (minted via DLC funding)
        if (params.initialAmount > 0) {
            params.valid = false;
            params.reason = 'DLC-backed tokens must have 0 initial supply';
            return params;
        }

        params.isDLCToken = true;
        return params;
    }
};

module.exports = { OracleValidity };
