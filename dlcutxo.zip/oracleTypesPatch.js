/**
 * Types.js Integration Patch for Oracle Staking & Fraud Proofs
 * 
 * Shows where to add the new cases following your existing patterns
 */

// ============================================
// IMPORTS TO ADD AT TOP OF FILES
// ============================================

/*
// txEncoder.js
const { OracleEncode } = require('./oracleEncode.js');

// txDecoder.js
const { OracleDecode } = require('./oracleDecode.js');

// validity.js
const { OracleValidity } = require('./oracleValidity.js');

// logic.js
const { OracleLogic } = require('./oracleLogic.js');

// oracle.js - Extend OracleList with:
const { OracleExtensions } = require('./oracleExtensions.js');
// Then add methods to OracleList class or use Object.assign

// main.js or wherever you need replay
const TokenizedUTXO = require('./tokenizedUTXO.js');
*/

// ============================================
// ENCODER ADDITIONS (txEncoder.js)
// ============================================

/*
encodeOracleStake: OracleEncode.encodeOracleStake,
encodeFraudProof: OracleEncode.encodeFraudProof,
encodeRegisterDLCAddress: OracleEncode.encodeRegisterDLCAddress,
encodeTokenIssueWithDLC: OracleEncode.encodeTokenIssueWithDLC,
*/

// ============================================
// DECODER ADDITIONS (txDecoder.js)
// ============================================

/*
decodeOracleStake: OracleDecode.decodeOracleStake,
decodeFraudProof: OracleDecode.decodeFraudProof,
decodeRegisterDLCAddress: OracleDecode.decodeRegisterDLCAddress,
decodeTokenIssueWithDLC: OracleDecode.decodeTokenIssueWithDLC,
*/

// ============================================
// TYPES.JS ENCODER SWITCH
// ============================================

/*
case 104:
    payload += Encode.encodeOracleStake(params);
    break;
case 105:
    payload += Encode.encodeFraudProof(params);
    break;
case 108:
    payload += Encode.encodeRegisterDLCAddress(params);
    break;
*/

// ============================================
// TYPES.JS DECODER SWITCH
// ============================================

/*
case 104:
    params = Decode.decodeOracleStake(encodedPayload.substr(index));
    params.block = block;
    params.senderAddress = sender;
    params.txid = txId;
    params = await Validity.validateOracleStake(sender, params, txId, block, tallyMapInstance, Oracles, activation);
    break;

case 105:
    params = Decode.decodeFraudProof(encodedPayload.substr(index));
    params.block = block;
    params.senderAddress = sender;
    params.txid = txId;
    // Resolve ref:N for challenge address
    if (params.challengeRef !== false) {
        const refOutput = reference.find(ref => ref.vout === params.challengeRef);
        if (refOutput) params.challengeAddress = refOutput.address;
    }
    params = await Validity.validateFraudProof(sender, params, txId, block, tallyMapInstance, Oracles, activation, persistence);
    break;

case 108:
    params = Decode.decodeRegisterDLCAddress(encodedPayload.substr(index));
    params.block = block;
    params.senderAddress = sender;
    params.txid = txId;
    // Resolve ref:N for taproot address
    if (params.taprootRef !== false) {
        const refOutput = reference.find(ref => ref.vout === params.taprootRef);
        if (refOutput) params.taprootAddress = refOutput.address;
    }
    params = await Validity.validateRegisterDLCAddress(sender, params, txId, block, Oracles, activation);
    break;
*/

// ============================================
// LOGIC.JS SWITCH
// ============================================

/*
case 104:
    if (params.valid) {
        await OracleLogic.executeOracleStake(params, tallyMapInstance, Oracles);
    }
    break;

case 105:
    if (params.valid) {
        await OracleLogic.executeFraudProof(params, tallyMapInstance, Oracles);
    }
    break;

case 108:
    if (params.valid) {
        await OracleLogic.executeRegisterDLCAddress(params, Oracles);
    }
    break;
*/

// ============================================
// EXTENDED TYPE 1 (Token Issue with DLC)
// ============================================

/*
// Modify existing case 1 in decoder:
case 1:
    params = Decode.decodeTokenIssueWithDLC(encodedPayload.substr(index));
    params.senderAddress = sender;
    params.block = block;
    if (params.dlcOracleId && params.dlcOracleId > 0) {
        params = await Validity.validateTokenIssueWithDLC(sender, params, txId, block, Oracles);
    } else {
        params = await Validity.validateTokenIssue(sender, params, txId);
    }
    break;

// In logic.js:
case 1:
    if (params.valid) {
        if (params.dlcOracleId && params.dlcOracleId > 0) {
            await OracleLogic.createDLCToken(params, propertyManager, Oracles);
        } else {
            await Logic.tokenIssue(params);
        }
    }
    break;
*/

// ============================================
// DATABASE COLLECTIONS NEEDED
// ============================================

/*
Add to db.js:
- 'oracleStakes'
- 'oracleAttestations'
- 'oracleChallenges'
- 'dlcAddresses'
*/

module.exports = {
    TX_ORACLE_STAKE: 104,
    TX_FRAUD_PROOF: 105,
    TX_REGISTER_DLC_ADDRESS: 108
};
