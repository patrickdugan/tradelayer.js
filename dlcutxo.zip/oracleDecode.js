/**
 * Oracle Staking & Fraud Proof Decoders
 * Add these to your existing txDecoder.js
 * 
 * Uses ref:N pattern for addresses (resolved in types.js from reference outputs)
 * Uses base36 decoding consistent with existing TradeLayer
 * 
 * Type 104: TX_ORACLE_STAKE
 * Type 105: TX_FRAUD_PROOF
 * Type 108: TX_REGISTER_DLC_ADDRESS
 */

const BigNumber = require('bignumber.js');

const OracleDecode = {

    /**
     * Type 104: TX_ORACLE_STAKE
     * Decode stake/unbond transaction
     */
    decodeOracleStake: (payload) => {
        const parts = payload.split(',');
        
        const action = parseInt(parts[0] || '0', 36);
        const oracleId = parseInt(parts[1] || '0', 36);
        const amount = new BigNumber(parts[2] || '0', 36).toString();
        const quorumId = parseInt(parts[3] || '0', 36);
        
        return {
            action,
            actionName: ['STAKE', 'REQUEST_UNBOND', 'COMPLETE_UNBOND', 'SLASH'][action] || 'UNKNOWN',
            oracleId,
            amount,
            quorumId
        };
    },

    /**
     * Type 105: TX_FRAUD_PROOF
     * Decode fraud proof challenge
     * 
     * Returns ref value for challenge address - resolved in types.js
     */
    decodeFraudProof: (payload) => {
        const parts = payload.split(',');
        
        const fraudType = parseInt(parts[0] || '0', 36);
        const oracleId = parseInt(parts[1] || '0', 36);
        const challengeBlock = parseInt(parts[2] || '0', 36);
        
        // Hashes are hex strings (truncated to 32 chars / 16 bytes)
        const activationCodeHash = parts[3] || '';
        const checkpointHash = parts[4] || '';
        
        // Parse ref:N pattern for challenge address
        let challengeRef = false;
        let challengeAddress = '';
        const refPart = parts[5] || '';
        if (refPart.startsWith('ref:')) {
            challengeRef = parseInt(refPart.split(':')[1], 10);
        } else {
            challengeAddress = refPart;
        }
        
        const claimedBalance = new BigNumber(parts[6] || '0', 36).toString();
        const actualBalance = new BigNumber(parts[7] || '0', 36).toString();
        
        return {
            fraudType,
            fraudTypeName: ['BALANCE_MISMATCH', 'DOUBLE_SPEND', 'INVALID_SETTLEMENT', 'STATE_REPLAY_FAIL'][fraudType] || 'UNKNOWN',
            oracleId,
            challengeBlock,
            activationCodeHash,
            checkpointHash,
            challengeRef,        // Vout reference to resolve
            challengeAddress,    // Direct address if provided
            claimedBalance,
            actualBalance,
            balanceDelta: (BigInt(actualBalance) - BigInt(claimedBalance)).toString()
        };
    },

    /**
     * Type 108: TX_REGISTER_DLC_ADDRESS
     * Decode DLC address registration
     * 
     * Returns ref value for taproot address - resolved in types.js
     */
    decodeRegisterDLCAddress: (payload) => {
        const parts = payload.split(',');
        
        const dlcOracleId = parseInt(parts[0] || '0', 36);
        
        // Parse ref:N pattern for taproot address
        let taprootRef = false;
        let taprootAddress = '';
        const refPart = parts[1] || '';
        if (refPart.startsWith('ref:')) {
            taprootRef = parseInt(refPart.split(':')[1], 10);
        } else {
            taprootAddress = refPart;
        }
        
        const rollSlot = parseInt(parts[2] || '0', 36);
        const enumBucket = parseInt(parts[3] || '0', 36);
        const autoRoll = parts[4] === '1';
        const cltvExpiry = parseInt(parts[5] || '0', 36);
        
        return {
            dlcOracleId,
            taprootRef,          // Vout reference to resolve
            taprootAddress,      // Direct address if provided
            rollSlot,
            enumBucket,
            autoRoll,
            cltvExpiry
        };
    },

    /**
     * Extended Token Issue decoder for DLC-backed tokens
     * 
     * Extends existing decodeTokenIssue to handle optional dlcOracleId
     */
    decodeTokenIssueWithDLC: (payload) => {
        const parts = payload.split(',');
        
        return {
            initialAmount: parts[0] ? parseInt(parts[0], 36) : 0,
            ticker: parts[1] || '',
            whitelists: parts[2] ? parts[2].split(';').map(val => parseInt(val, 36)) : [],
            managed: parts[3] === '1',
            backupAddress: parts[4] || '',
            nft: parts[5] === '1',
            coloredCoinHybrid: parts[6] === '1',
            // NEW: DLC oracle ID - if > 0, this is a DLC-backed token
            dlcOracleId: parts[7] ? parseInt(parts[7], 36) : 0
        };
    }
};

module.exports = { OracleDecode };
