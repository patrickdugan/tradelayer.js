/**
 * Oracle.js Extensions for DLC Oracle State Management
 * 
 * Add these methods to your existing oracle.js OracleList class
 * 
 * Handles:
 * - DLC oracle creation and configuration
 * - Staking state (stake, unbonding, slashing)
 * - Attestations and their invalidation
 * - DLC address registrations
 * - Roll window slot tracking for throughput attenuation
 */

const db = require('./db');
const BigNumber = require('bignumber.js');

// Constants
const UNBONDING_PERIOD_BLOCKS = 1008; // ~1 week
const MIN_STAKE_SATS = 10000n;        // 0.0001 BTC minimum
const SLASH_REWARD_PERCENT = 20;       // Challenger gets 20%
const FRAUD_PROOF_BOND = 1000n;        // Bond to submit fraud proof

/**
 * DLC Oracle Extensions - Add these methods to OracleList class
 */
const OracleExtensions = {

    // ============================================
    // DLC ORACLE CREATION (extends createOracle)
    // ============================================

    /**
     * Create a DLC-enabled oracle with roll window configuration
     */
    createDLCOracle: async function(name, adminAddress, dlcConfig) {
        const instance = this.getInstance();
        const oracleId = this.getNextId();
        const oracleKey = `oracle-${oracleId}`;

        const numSlots = Math.ceil(7 * 144 / (dlcConfig.rollWindow || 1008));

        const newOracle = {
            _id: oracleKey,
            id: oracleId,
            name: name,
            adminAddress: adminAddress,
            data: {},
            // DLC-specific fields
            isDLCOracle: true,
            enumType: dlcConfig.enumType || 1,           // Default: INCREMENTAL_5
            rollWindow: dlcConfig.rollWindow || 1008,    // Default: 1 week
            minStake: dlcConfig.minStake || '100000000', // Default: 1 BTC
            dlcTemplateHash: dlcConfig.dlcTemplateHash || '',
            maturityWindow: dlcConfig.maturityWindow || 1008,
            maxTVLRatio: dlcConfig.maxTVLRatio || 10,
            sbtcPropertyId: dlcConfig.sbtcPropertyId || 0,
            totalStake: '0',
            activeFundings: 0,
            totalTVL: '0',
            // Roll slots for throughput attenuation
            rollSlots: Array(numSlots).fill(null).map(() => ({
                fundedAmount: '0',
                registeredAddresses: [],
                nextSettlementBlock: 0
            }))
        };

        const oracleDB = await db.getDatabase('oracleList');
        await oracleDB.insertAsync(newOracle);
        instance.oracles.set(oracleKey, newOracle);

        console.log(`DLC Oracle created: ID ${oracleId}, Name: ${name}, Enum: ${dlcConfig.enumType}`);
        return oracleId;
    },

    // ============================================
    // STAKING MANAGEMENT
    // ============================================

    /**
     * Get stake for an address
     */
    getStake: async function(oracleId, address) {
        const stakeDB = await db.getDatabase('oracleStakes');
        const key = `stake-${oracleId}-${address}`;
        const stake = await stakeDB.findOneAsync({ _id: key });
        return stake;
    },

    /**
     * Set stake for an address
     */
    setStake: async function(oracleId, address, stakeData) {
        const stakeDB = await db.getDatabase('oracleStakes');
        const key = `stake-${oracleId}-${address}`;
        
        await stakeDB.updateAsync(
            { _id: key },
            { _id: key, oracleId, address, ...stakeData },
            { upsert: true }
        );
    },

    /**
     * Delete stake record
     */
    deleteStake: async function(oracleId, address) {
        const stakeDB = await db.getDatabase('oracleStakes');
        const key = `stake-${oracleId}-${address}`;
        await stakeDB.removeAsync({ _id: key }, {});
    },

    /**
     * Update oracle total stake
     */
    updateTotalStake: async function(oracleId, delta) {
        const oracle = await this.getOracleInfo(oracleId);
        if (!oracle) return '0';
        
        const newTotal = (BigInt(oracle.totalStake || '0') + BigInt(delta)).toString();
        
        const oracleDB = await db.getDatabase('oracleList');
        const oracleKey = `oracle-${oracleId}`;
        await oracleDB.updateAsync(
            { _id: oracleKey },
            { $set: { totalStake: newTotal } },
            {}
        );
        
        // Update in-memory
        const instance = this.getInstance();
        if (instance.oracles.has(oracleKey)) {
            const oracleData = instance.oracles.get(oracleKey);
            oracleData.totalStake = newTotal;
            instance.oracles.set(oracleKey, oracleData);
        }
        
        return newTotal;
    },

    /**
     * Get all stakers for an oracle
     */
    getOracleStakers: async function(oracleId) {
        const stakeDB = await db.getDatabase('oracleStakes');
        const stakes = await stakeDB.findAsync({ oracleId: oracleId });
        return stakes;
    },

    // ============================================
    // ATTESTATION MANAGEMENT
    // ============================================

    /**
     * Store an oracle attestation (balance claim for an address at a block)
     */
    setAttestation: async function(oracleId, block, address, attestationData) {
        const attestDB = await db.getDatabase('oracleAttestations');
        const key = `attest-${oracleId}-${block}-${address}`;
        
        await attestDB.updateAsync(
            { _id: key },
            { 
                _id: key, 
                oracleId, 
                block, 
                address,
                ...attestationData,
                createdAt: Date.now(),
                invalidated: false
            },
            { upsert: true }
        );
    },

    /**
     * Get attestation
     */
    getAttestation: async function(oracleId, block, address) {
        const attestDB = await db.getDatabase('oracleAttestations');
        const key = `attest-${oracleId}-${block}-${address}`;
        return await attestDB.findOneAsync({ _id: key });
    },

    /**
     * Invalidate an attestation (after fraud proof)
     */
    invalidateAttestation: async function(oracleId, block, address, invalidationData) {
        const attestDB = await db.getDatabase('oracleAttestations');
        const key = `attest-${oracleId}-${block}-${address}`;
        
        await attestDB.updateAsync(
            { _id: key },
            { $set: { 
                invalidated: true,
                invalidatedBy: invalidationData.invalidatedBy,
                invalidatedBlock: invalidationData.invalidatedBlock,
                invalidatedTxid: invalidationData.invalidatedTxid,
                actualBalance: invalidationData.actualBalance
            }},
            {}
        );
    },

    // ============================================
    // FRAUD CHALLENGE MANAGEMENT
    // ============================================

    /**
     * Get active fraud challenges against an address
     */
    getActiveChallenges: async function(oracleId, address) {
        const challengeDB = await db.getDatabase('oracleChallenges');
        const challenges = await challengeDB.findAsync({ 
            oracleId, 
            targetAddress: address,
            status: 'active'
        });
        return challenges;
    },

    /**
     * Create a fraud challenge
     */
    createChallenge: async function(oracleId, address, challengeData) {
        const challengeDB = await db.getDatabase('oracleChallenges');
        const key = `challenge-${oracleId}-${challengeData.txid}`;
        
        await challengeDB.insertAsync({
            _id: key,
            oracleId,
            targetAddress: address,
            status: 'active',
            createdAt: Date.now(),
            ...challengeData
        });
    },

    /**
     * Resolve a fraud challenge
     */
    resolveChallenge: async function(oracleId, txid, resolution) {
        const challengeDB = await db.getDatabase('oracleChallenges');
        const key = `challenge-${oracleId}-${txid}`;
        
        await challengeDB.updateAsync(
            { _id: key },
            { $set: { 
                status: resolution.confirmed ? 'confirmed' : 'rejected',
                resolvedAt: Date.now(),
                resolution
            }},
            {}
        );
    },

    // ============================================
    // DLC ADDRESS MANAGEMENT
    // ============================================

    /**
     * Register a DLC address
     */
    registerDLCAddress: async function(registration) {
        const dlcAddrDB = await db.getDatabase('dlcAddresses');
        const key = `dlc-${registration.taprootAddress}`;
        
        await dlcAddrDB.insertAsync({
            _id: key,
            ...registration,
            status: 'REGISTERED',
            fundedAmount: '0',
            fundedTxid: null,
            fundedVout: null,
            settlementOutcome: null,
            settlementBlock: null
        });

        // Update oracle roll slot
        const oracle = await this.getOracleInfo(registration.dlcOracleId);
        if (oracle && oracle.rollSlots) {
            oracle.rollSlots[registration.rollSlot].registeredAddresses.push(registration.taprootAddress);
            
            const oracleDB = await db.getDatabase('oracleList');
            const oracleKey = `oracle-${registration.dlcOracleId}`;
            await oracleDB.updateAsync(
                { _id: oracleKey },
                { $set: { rollSlots: oracle.rollSlots } },
                {}
            );
        }
    },

    /**
     * Get DLC address registration
     */
    getDLCAddressRegistration: async function(taprootAddress) {
        const dlcAddrDB = await db.getDatabase('dlcAddresses');
        const key = `dlc-${taprootAddress}`;
        return await dlcAddrDB.findOneAsync({ _id: key });
    },

    /**
     * Update DLC address status
     */
    updateDLCAddress: async function(taprootAddress, updates) {
        const dlcAddrDB = await db.getDatabase('dlcAddresses');
        const key = `dlc-${taprootAddress}`;
        await dlcAddrDB.updateAsync({ _id: key }, { $set: updates }, {});
    },

    /**
     * Get DLC addresses for a roll slot
     */
    getDLCsInRollSlot: async function(oracleId, rollSlot) {
        const dlcAddrDB = await db.getDatabase('dlcAddresses');
        return await dlcAddrDB.findAsync({ dlcOracleId: oracleId, rollSlot: rollSlot });
    },

    // ============================================
    // ROLL WINDOW ATTENUATION
    // ============================================

    /**
     * Get current roll slot based on block height
     */
    getCurrentRollSlot: async function(oracleId, currentBlock) {
        const oracle = await this.getOracleInfo(oracleId);
        if (!oracle || !oracle.isDLCOracle) return 0;
        
        const rollWindow = oracle.rollWindow;
        const numSlots = oracle.rollSlots.length;
        
        return Math.floor(currentBlock / rollWindow) % numSlots;
    },

    /**
     * Get TVL for a specific roll slot
     */
    getRollSlotTVL: async function(oracleId, rollSlot) {
        const dlcs = await this.getDLCsInRollSlot(oracleId, rollSlot);
        
        let totalTVL = 0n;
        for (const dlc of dlcs) {
            if (dlc.status === 'FUNDED') {
                totalTVL += BigInt(dlc.fundedAmount || '0');
            }
        }
        return totalTVL.toString();
    },

    /**
     * Check if roll slot has capacity for new funding
     */
    checkRollSlotCapacity: async function(oracleId, rollSlot, fundingAmount) {
        const oracle = await this.getOracleInfo(oracleId);
        if (!oracle) return { hasCapacity: false };
        
        const totalStake = BigInt(oracle.totalStake || '0');
        const maxTVLRatio = BigInt(oracle.maxTVLRatio || 10);
        const numSlots = BigInt(oracle.rollSlots?.length || 7);
        
        // Max TVL per slot = (totalStake * maxTVLRatio) / numSlots
        const maxSlotTVL = (totalStake * maxTVLRatio) / numSlots;
        
        const currentTVL = BigInt(await this.getRollSlotTVL(oracleId, rollSlot));
        const newTVL = currentTVL + BigInt(fundingAmount);
        
        return {
            hasCapacity: newTVL <= maxSlotTVL,
            currentTVL: currentTVL.toString(),
            maxTVL: maxSlotTVL.toString(),
            available: (maxSlotTVL - currentTVL).toString()
        };
    },

    // ============================================
    // SLASH COMPUTATION
    // ============================================

    /**
     * Compute slash amount based on discrepancy
     */
    computeSlashAmount: async function(oracleId, oracleAddress, claimedBalance, actualBalance) {
        const stake = await this.getStake(oracleId, oracleAddress);
        if (!stake) return '0';
        
        const stakeAmount = BigInt(stake.amount || '0');
        const claimed = BigInt(claimedBalance);
        const actual = BigInt(actualBalance);
        
        const discrepancy = claimed > actual 
            ? claimed - actual 
            : actual - claimed;
        
        // Slash 10-100% based on discrepancy ratio
        let discrepancyRatio = discrepancy * 100n / (claimed > 0n ? claimed : 1n);
        if (discrepancyRatio > 100n) discrepancyRatio = 100n;
        if (discrepancyRatio < 10n) discrepancyRatio = 10n;
        
        const slashAmount = (stakeAmount * discrepancyRatio) / 100n;
        return slashAmount.toString();
    }
};

// Export constants and extensions
module.exports = {
    OracleExtensions,
    UNBONDING_PERIOD_BLOCKS,
    MIN_STAKE_SATS,
    SLASH_REWARD_PERCENT,
    FRAUD_PROOF_BOND
};
