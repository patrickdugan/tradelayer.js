#[derive(Copy, Drop, Serde)]
pub struct TlzkBatchClaim {
    pub batch_id_hi: u128,
    pub batch_id_lo: u128,
    pub transition_root_hi: u128,
    pub transition_root_lo: u128,
    pub final_root_hi: u128,
    pub final_root_lo: u128,
    pub receipt_count: u32,
    pub valid_receipt_count: u32,
    pub binding_commitment: felt252,
}

#[derive(Copy, Drop, Serde)]
pub struct TlzkBatchOutput {
    pub ok: felt252,
    pub receipt_count: u32,
    pub valid_receipt_count: u32,
    pub binding_commitment: felt252,
}

fn mix(left: felt252, right: felt252) -> felt252 {
    left * 31 + right * 17 + 7
}

fn mix_limbs(hi: u128, lo: u128) -> felt252 {
    let hi_felt: felt252 = hi.into();
    let lo_felt: felt252 = lo.into();
    mix(hi_felt, lo_felt)
}

pub fn compute_batch_binding(claim: @TlzkBatchClaim) -> felt252 {
    let batch_id = mix_limbs(*claim.batch_id_hi, *claim.batch_id_lo);
    let transition_root = mix_limbs(*claim.transition_root_hi, *claim.transition_root_lo);
    let final_root = mix_limbs(*claim.final_root_hi, *claim.final_root_lo);
    let receipt_count: felt252 = (*claim.receipt_count).into();
    let valid_receipt_count: felt252 = (*claim.valid_receipt_count).into();

    let roots = mix(batch_id, transition_root);
    let counts = mix(receipt_count, valid_receipt_count);
    mix(mix(roots, final_root), counts)
}

#[executable]
fn main(claim: TlzkBatchClaim) -> TlzkBatchOutput {
    assert(claim.receipt_count > 0, 'empty batch');
    assert(claim.valid_receipt_count <= claim.receipt_count, 'bad count');

    let expected_binding = compute_batch_binding(@claim);
    assert(claim.binding_commitment == expected_binding, 'bad binding');

    TlzkBatchOutput {
        ok: 1,
        receipt_count: claim.receipt_count,
        valid_receipt_count: claim.valid_receipt_count,
        binding_commitment: expected_binding,
    }
}
