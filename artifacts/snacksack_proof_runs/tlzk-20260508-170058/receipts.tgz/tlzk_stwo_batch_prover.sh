#!/usr/bin/env bash
set -euo pipefail

BATCH_PATH="${1:-batch.json}"
ARK_ROOT="${ARK_SHINIGAMI_REMOTE:-/home/snacksack/ark-shinigami-remote}"
SCARB="${SCARB:-$ARK_ROOT/tools/scarb-v2.18.0/scarb-v2.18.0-x86_64-unknown-linux-gnu/bin/scarb}"
STWO_RUN_AND_PROVE="${STWO_RUN_AND_PROVE:-$ARK_ROOT/tools/bin/run_and_prove}"

if [ ! -f "$BATCH_PATH" ]; then
  echo "missing batch JSON: $BATCH_PATH" >&2
  exit 2
fi
if [ ! -x "$SCARB" ]; then
  echo "missing scarb executable: $SCARB" >&2
  exit 2
fi
if [ ! -x "$STWO_RUN_AND_PROVE" ]; then
  echo "missing STWO run_and_prove executable: $STWO_RUN_AND_PROVE" >&2
  exit 2
fi

WORK_DIR="${TLZK_STWO_WORK_DIR:-$(pwd)/tlzk_stwo}"
PKG_DIR="$WORK_DIR/cairo_batch_binding"
mkdir -p "$PKG_DIR/src"

cat > "$PKG_DIR/Scarb.toml" <<'TOML'
[package]
name = "tlzk_batch_binding"
version = "0.1.0"
edition = "2024_07"

[dependencies]
cairo_execute = "2.18.0"

[cairo]
sierra-replace-ids = true
enable-gas = false

[[target.executable]]
TOML

cat > "$PKG_DIR/src/lib.cairo" <<'CAIRO'
#[derive(Copy, Drop, Serde)]
pub struct TlzkBatchClaim {
    pub batch_id_hi: u128,
    pub batch_id_lo: u128,
    pub transition_root_hi: u128,
    pub transition_root_lo: u128,
    pub final_root_hi: u128,
    pub final_root_lo: u128,
    pub receipt_count: u32,
    pub valid_receipt_count: u32,
    pub binding_commitment: felt252,
}

#[derive(Copy, Drop, Serde)]
pub struct TlzkBatchOutput {
    pub ok: felt252,
    pub receipt_count: u32,
    pub valid_receipt_count: u32,
    pub binding_commitment: felt252,
}

fn mix(left: felt252, right: felt252) -> felt252 {
    left * 31 + right * 17 + 7
}

fn mix_limbs(hi: u128, lo: u128) -> felt252 {
    let hi_felt: felt252 = hi.into();
    let lo_felt: felt252 = lo.into();
    mix(hi_felt, lo_felt)
}

pub fn compute_batch_binding(claim: @TlzkBatchClaim) -> felt252 {
    let batch_id = mix_limbs(*claim.batch_id_hi, *claim.batch_id_lo);
    let transition_root = mix_limbs(*claim.transition_root_hi, *claim.transition_root_lo);
    let final_root = mix_limbs(*claim.final_root_hi, *claim.final_root_lo);
    let receipt_count: felt252 = (*claim.receipt_count).into();
    let valid_receipt_count: felt252 = (*claim.valid_receipt_count).into();

    let roots = mix(batch_id, transition_root);
    let counts = mix(receipt_count, valid_receipt_count);
    mix(mix(roots, final_root), counts)
}

#[executable]
fn main(claim: TlzkBatchClaim) -> TlzkBatchOutput {
    assert(claim.receipt_count > 0, 'empty batch');
    assert(claim.valid_receipt_count <= claim.receipt_count, 'bad count');

    let expected_binding = compute_batch_binding(@claim);
    assert(claim.binding_commitment == expected_binding, 'bad binding');

    TlzkBatchOutput {
        ok: 1,
        receipt_count: claim.receipt_count,
        valid_receipt_count: claim.valid_receipt_count,
        binding_commitment: expected_binding,
    }
}
CAIRO

python3 - "$BATCH_PATH" "$WORK_DIR" <<'PY'
import json
import pathlib
import sys

FIELD = 2**251 + 17 * 2**192 + 1

def require_hex32(value, field):
    text = str(value or "").lower().removeprefix("0x")
    if len(text) != 64:
        raise SystemExit(f"{field} must be a 32-byte hex string, got {value!r}")
    int(text, 16)
    return text

def limbs(hex32):
    return int(hex32[:32], 16), int(hex32[32:], 16)

def mix(left, right):
    return (left * 31 + right * 17 + 7) % FIELD

def mix_limbs(hi, lo):
    return mix(hi, lo)

batch_path = pathlib.Path(sys.argv[1])
work_dir = pathlib.Path(sys.argv[2])
batch = json.loads(batch_path.read_text(encoding="utf-8"))
core = batch.get("batchCore", {})
receipts = batch.get("transitionReceipts", [])

batch_id = require_hex32(batch.get("batchId"), "batchId")
transition_root = require_hex32(core.get("transitionRoot"), "batchCore.transitionRoot")
final_root = require_hex32(core.get("finalStateRoot"), "batchCore.finalStateRoot")
receipt_count = len(receipts)
valid_receipt_count = sum(1 for receipt in receipts if receipt.get("receiptCore", {}).get("valid") is not False)

batch_hi, batch_lo = limbs(batch_id)
transition_hi, transition_lo = limbs(transition_root)
final_hi, final_lo = limbs(final_root)
batch_felt = mix_limbs(batch_hi, batch_lo)
transition_felt = mix_limbs(transition_hi, transition_lo)
final_felt = mix_limbs(final_hi, final_lo)
roots = mix(batch_felt, transition_felt)
counts = mix(receipt_count, valid_receipt_count)
binding = mix(mix(roots, final_felt), counts)

args = [
    hex(batch_hi),
    hex(batch_lo),
    hex(transition_hi),
    hex(transition_lo),
    hex(final_hi),
    hex(final_lo),
    hex(receipt_count),
    hex(valid_receipt_count),
    hex(binding),
]
claim = {
    "kind": "tlzk_stwo_batch_binding_claim",
    "batchId": batch_id,
    "transitionRoot": transition_root,
    "finalStateRoot": final_root,
    "receiptCount": receipt_count,
    "validReceiptCount": valid_receipt_count,
    "bindingCommitment": hex(binding),
    "field": "cairo_felt252",
}
(work_dir / "args.json").write_text(json.dumps(args, indent=2) + "\n", encoding="utf-8")
(work_dir / "claim.json").write_text(json.dumps(claim, indent=2) + "\n", encoding="utf-8")
print(json.dumps(claim, indent=2))
PY

cd "$PKG_DIR"
"$SCARB" build --no-warnings
PROGRAM="$(find target -type f -name '*.executable.json' | sort | head -1)"
if [ -z "$PROGRAM" ]; then
  echo "scarb did not produce an executable JSON" >&2
  exit 3
fi

PROOF_PATH="$WORK_DIR/proof.json"
STWO_LOG="$WORK_DIR/stwo.log"
STWO_TIME="$WORK_DIR/stwo_time.log"
/usr/bin/time -v "$STWO_RUN_AND_PROVE" \
  --program "$PROGRAM" \
  --program_type executable \
  --program_arguments_file "$WORK_DIR/args.json" \
  --proof_path "$PROOF_PATH" \
  --verify \
  > "$STWO_LOG" 2> "$STWO_TIME"

python3 - "$WORK_DIR" "$PROGRAM" "$PROOF_PATH" <<'PY'
import hashlib
import json
import pathlib
import sys

work_dir = pathlib.Path(sys.argv[1])
program = pathlib.Path(sys.argv[2])
proof = pathlib.Path(sys.argv[3])
claim = json.loads((work_dir / "claim.json").read_text(encoding="utf-8"))
summary = {
    "kind": "tlzk_stwo_batch_proof_summary",
    "mode": "stwo-cairo",
    "program": str(program),
    "programSha256": hashlib.sha256(program.read_bytes()).hexdigest(),
    "proofPath": str(proof),
    "proofSha256": hashlib.sha256(proof.read_bytes()).hexdigest(),
    "proofBytes": proof.stat().st_size,
    **claim,
}
(work_dir / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
print(json.dumps(summary, indent=2))
PY
