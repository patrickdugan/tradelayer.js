set -euo pipefail
cd "/home/snacksack/tlzk-proof-runs/tlzk-20260508-160150"
started_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)
printf '{"kind":"tlzk_snacksack_proof_run","runId":"tlzk-20260508-160150","host":"snacksack-ms-7d32","batch":"batch.json","startedAt":"%s"}\n' "$started_at" > run-start.json
PROVER_COMMAND_B64="YmFzaCAuL3Rsemtfc3R3b19iYXRjaF9wcm92ZXIuc2g="
if [ -n "$PROVER_COMMAND_B64" ]; then
  PROVER_COMMAND=$(printf '%s' "$PROVER_COMMAND_B64" | base64 -d)
  /usr/bin/time -v sh -lc "$PROVER_COMMAND batch.json" > prover.log 2> time.log
else
  python3 - <<'PY' | tee prover.log
import json
with open("batch.json", "r", encoding="utf-8") as fh:
    batch = json.load(fh)
print(json.dumps({
    "ok": True,
    "mode": "receipt-only",
    "batchId": batch.get("batchId", ""),
    "receiptCount": len(batch.get("transitionReceipts", []))
}, indent=2))
PY
  /usr/bin/time -v python3 - <<'PY' > parse.log 2> time.log
import json
with open("batch.json", "r", encoding="utf-8") as fh:
    json.load(fh)
print("parsed batch")
PY
fi
{
  printf '%s\n' batch.json prover.log time.log run-start.json run.sh
  if [ -f tlzk_stwo_batch_prover.sh ]; then
    printf '%s\n' tlzk_stwo_batch_prover.sh
  fi
  if [ -d tlzk_stwo ]; then
    find tlzk_stwo -maxdepth 4 -type f | sort
  fi
} > receipts.files

xargs -r sha256sum < receipts.files > receipts.sha256
if [ -d tlzk_stwo ]; then
  find tlzk_stwo -maxdepth 4 -type f -print0 | sort -z | xargs -0 -r sha256sum > tlzk_stwo/receipts.sha256
fi
printf '%s\n' receipts.sha256 receipts.files >> receipts.files
tar -czf receipts.tgz -T receipts.files